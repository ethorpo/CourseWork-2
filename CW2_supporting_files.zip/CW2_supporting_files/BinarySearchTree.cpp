#include "bst.h"

// Creates an empty binary tree
BinarySearchTree::BinarySearchTree()
{
}

// Creates a binary tree with an initial value to store
BinarySearchTree::BinarySearchTree(string word)
{
}

// Creates a binary tree by copying an existing tree
BinarySearchTree::BinarySearchTree(const BinarySearchTree &rhs)
{

}

// Destroys (cleans up) the tree
BinarySearchTree::~BinarySearchTree()
{
    
}

// Adds a word to the tree
void BinarySearchTree::insert(string word)
{
}

// Removes a word from the tree
void BinarySearchTree::remove(string word)
{

}

// Checks if a word is in the tree
bool BinarySearchTree::exists(string word) const
{
    return true;
}

// Prints the tree to standard out in numerical order
std::string BinarySearchTree::inorder() const
{
    return std::string("");
}

// Prints the tree in pre-order
std::string BinarySearchTree::preorder() const
{
    return std::string("");
}

// Prints the tree in post-order
std::string BinarySearchTree::postorder() const
{
    return std::string("");
}


// Checks if two trees are equal
bool BinarySearchTree::operator==(const BinarySearchTree &other) const
{
    return true;
}

// Checks if two trees are not equal
bool BinarySearchTree::operator!=(const BinarySearchTree &other) const
{
    return true;
}


// Reads in words from an input stream into the tree
std::istream& operator>>(std::istream &in, BinarySearchTree &tree)
{
    return in;
}

// Writes the words, in-order, to an output stream
std::ostream& operator<<(std::ostream &out, const BinarySearchTree &tree)
{
    return out;
}
